import React, { Component } from "react";
import { BrowserRouter, Route,  Redirect, Switch } from "react-router-dom";
import Home from './components/pages/home'
import { GlobalProvider } from './context/auth-context';
import { GlobalContext } from "./context/auth-context";
import Registration from "./components/pages/registration";
import Login from "./components/pages/login";
import { extendTheme } from "@chakra-ui/react"
import { ChakraProvider } from "@chakra-ui/react"
import Cash from "./components/pages/cash";
import Retrait from "./components/pages/retrait";
import Envoi from "./components/pages/envoi";
const colors = {
  brand: {
    900: "#322659",
    800: "#44337A",
    700: "#ca0415ea",
  },
}

const theme = extendTheme({ colors })

class App extends Component {
static contextType = GlobalContext;
  render() {
    return (
      <ChakraProvider theme={theme}>
        <GlobalProvider>
          <BrowserRouter>
              <Switch>
                <Route exact  path="/" component={Home}/>
                <Route path="/login" component={Login}/>
                <Route path="/create" component={Registration} />
                <Route path="/cash" component={Cash} />
                <Route path="/retrait" component={Retrait} />
                <Route path="/envoi" component={Envoi} />
              </Switch>
          </BrowserRouter>
      </GlobalProvider>
      </ChakraProvider>
      
    );
  }
}

export default App;
