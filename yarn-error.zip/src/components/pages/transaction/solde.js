import React, { useState, useContext } from "react";
import {
    Button,
    Modal,
    ModalBody,
    ModalCloseButton,
    ModalContent,
    ModalOverlay,
    ModalFooter,
    ModalHeader,
    Input,
    FormControl,
    useDisclosure,
    InputLeftAddon,
    InputGroup,
    HStack,
    PinInput,
    PinInputField,
    Box
} from "@chakra-ui/react";
import BigInt from "big-integer"
import CryptoJS from "crypto-js"
import { GlobalContext } from "../../../context/auth-context";
import axios from 'axios';
const Solde = () => {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const [solde, setSolde] = useState(0.0);
    const [soldeHide, setSoldeHide] = useState(false);
    const context = useContext(GlobalContext);
    const [pin, setPin] = useState("")
    const openPin = (event) => {
        event.preventDefault();
        onOpen()
    }
    const getSolde = async (event) => {
        event.preventDefault();

        try {
            const P = BigInt(CryptoJS.SHA256(pin), 16)
            const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)
            await axios.get("/solde") .then((res) => {
                    if (res.status !== 200 && res.status !== 201) {
                        throw new Error("Failed");
                    }
                const dataResponse = context.decrypt(dataSK.SK, context.IV, res.data.response)   
                onClose();
                setSolde(dataResponse.solde);
                setSoldeHide(!soldeHide);

                })
                .catch((err, res) => {
                    console.log(err);
                });
        } catch (err) {
            console.log(err)
        }
    };
    return (

        <>
            {soldeHide ? <Button width="xs"
                mt={4}
                border="2px"
                borderColor="brand.700"
                variant="solid"
                background="brand.700"
                color="white"
                onClick={() => { setSoldeHide(!soldeHide) }} >
                {solde} XFA
                </Button> :
                <Button width="xs"
                    mt={4}
                    border="2px"
                    borderColor="brand.700"
                    variant="solid"
                    background="brand.700"
                    color="white"
                    onClick={openPin}>
                    Voir le solde
               </Button>}

            <Modal
                isOpen={isOpen}
                onClose={onClose}
                id="pin"
                size="xs"
            >
                <ModalOverlay />
                <ModalContent>
                <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box>
                    </ModalHeader>
                    <ModalCloseButton />
                    <ModalBody pb={6}>
                        <form onSubmit={getSolde}>
                            <Box
                                borderWidth={1}
                                width="full"
                                p={4}
                                borderRadius={4}
                                boxShadow="lg"
                                textAlign="center"
                                alignContent="center"
                            >
                                <FormControl mt={4} isRequired>
                                    <HStack align="center">
                                        <PinInput
                                            onChange={(value) => { setPin(value) }}
                                            mask>
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                        </PinInput>
                                    </HStack>

                                </FormControl>
                            </Box>
                            <HStack mt={4}>
                                <Button
                                    border="2px"
                                    width="lg"
                                    borderColor="brand.700"
                                    variant="solid"
                                    background="brand.700"
                                    color="white"
                                    variant="outline"
                                    mr={3}
                                    type="submit"
                                    onClick={onClose}>
                                    Valider
                 </Button>

                            </HStack>
                        </form>

                    </ModalBody>
                </ModalContent>
            </Modal>
        </>
    );
};
export default Solde;
