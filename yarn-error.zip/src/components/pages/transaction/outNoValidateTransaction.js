import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
import {
    Box,
    Text,
    AlertDialog,
    AlertDialogBody,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogContent,
    AlertDialogOverlay,
    Button,
    AlertDialogCloseButton,
    useDisclosure
} from "@chakra-ui/react";
const ListeOutNoValidateTransaction = (props) => {

    const { isOpen, onOpen, onClose } = useDisclosure()
    const cancelRef = React.useRef()
    const [item, setItem] = useState({})

    return (
        <>

            <ul>
                {props.outNoValidateTransactions.map(item => (
                    <li key={item.id}>
                        <Box
                            borderWidth={1}
                            width="full"
                            p={2}
                            borderRadius={2}
                            textAlign="center"
                            boxShadow="lg"
                            align='center'
                            m={2}
                            borderColor="brand.700"
                            onClick={() => {setItem(item); onOpen()}}
                        >
                            <Text fontWeight="bold">
                                La somme de {item.montant} XFA envoyé est en cours de validation.
                            </Text>
                            <Text fontSize="sm">Envoyé le {item.dateEnvoi} </Text>
                        </Box>
                    </li>
                ))}
            </ul>
            <AlertDialog
                motionPreset="slideInBottom"
                leastDestructiveRef={cancelRef}
                onClose={onClose}
                isOpen={isOpen}
                isCentered
                item={item}
            >
                <AlertDialogOverlay />

                <AlertDialogContent>
                    <AlertDialogHeader>Transaction</AlertDialogHeader>
                    <AlertDialogCloseButton />
                    <AlertDialogBody>
                            <Text fontWeight="bold">
                                La somme de {item.montant} XFA envoyé est en cours de validation.
                            </Text>
                            <Text fontWeight="bold">
                                Code de validation {item.code}.
                            </Text>
                            <Text fontSize="sm">Envoyé le {item.dateEnvoi} </Text>
          </AlertDialogBody>
                    <AlertDialogFooter>
                        <Button ref={cancelRef} onClick={onClose}>
                            Quitter
            </Button>

                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};

export default ListeOutNoValidateTransaction;