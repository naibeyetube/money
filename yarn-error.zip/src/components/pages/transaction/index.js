import React, { useState, useContext , useEffect} from 'react'
import { Tabs, TabList, TabPanels, Tab, TabPanel, Box, Flex, Button
} from "@chakra-ui/react";
import ActiviteSend from '../envoi';
import ActiviteReceive from '../retrait';
import Profil from "../profile/"
import Grille from '../grille';
import Solde from './solde';
import BigInt from 'big-integer'
import  CryptoJS from 'crypto-js'
import axios from 'axios'
import { GlobalContext } from "../../../context/auth-context";
import ListeIntransaction from './inTransaction';
import ListeOutValideTransaction from './outValidateTransaction';
import ListeOutNoValidateTransaction from './outNoValidateTransaction';
const Transaction = (props) => {
  const [profile, setProfile] = useState({ id: "" })
  const [transactions, setTransactions] = useState({})
  const [inTransactions, setInTransactions] = useState([])
  const [outValidateTransactions, setOutValideTransactions] = useState([])
  const [outNoValidateTransactions, setOutNoValideTransactions] = useState([])
  const role= props.dataUser.profile_id===1?true:false;
  const getProfile = (item) => {
    setProfile({ ...item })
  }
  const context = useContext(GlobalContext);
  useEffect(async () => {
    const P = BigInt(CryptoJS.SHA256(props.pin), 16)
    const SK = await sessionStorage.getItem('dataSK');
    const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, SK)
    await axios.get( `/transactions/${5}`).then((res) => {
      if (res.status !== 200 && res.status !== 201) {
        throw new Error("Failed");
      }
      return res.data
    }).then((data) => {
      const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
      setInTransactions([...dataResponse.inTransactions])
      setOutValideTransactions([...dataResponse.outValidateTransactions])
      setOutNoValideTransactions([...dataResponse.outNoValidateTransactions])
      
    })
  }, [ props.pin]);
  return (
    <React.Fragment>
      <section className="about" id="about">
        <div className="max-width">
          <div className="about-content">

            <Flex minHeight='100vh' width='100%' justifyContent='center'>

              <Box
                borderWidth={1}
                width="full"
                borderRadius={4}
                textAlign="center"
                boxShadow="lg"
                align='center'
                fontSize={{ base: "12px", md: "14px", lg: "16px" }}
              >
                <Box
                borderWidth={1}
                width="full"
                borderRadius={4}
                textAlign="center"
                boxShadow="lg"
                align='center'
                fontSize={{ base: "12px", md: "14px", lg: "16px" }}
              >
               {props.dataUser && <Button width="xs"
                my={4}
                border="2px"
                borderColor="brand.700"
                variant="solid"
             >
                Compte de {props.dataUser.nom} {props.dataUser.prenom}
                </Button> }
                </Box>

                  <Solde />
                <Tabs
                  variant="enclosed" borderRadius={4}
                  fontSize={{ base: "10px", md: "16px", lg: "16px" }}
                  align='center'
                >
                  <TabList>
                    <Tab _selected={{ color: "white", bg: "brand.700" }}
                      mt={4}
                      border="2px"
                      borderColor="brand.700"
                      variant="solid"
                      fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                    >{role?"Depôt":"Transfert"}</Tab>
                    <Tab _selected={{ color: "white", bg: "brand.700" }}
                      mt={4}
                      border="2px"
                      borderColor="brand.700"
                      variant="solid"
                      fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                    >{role?"Retrait":"Depôt"}</Tab>
                    {role &&
                    <Tab _selected={{ color: "white", bg: "brand.700" }}
                      mt={4}
                      border="2px"
                      borderColor="brand.700"
                      variant="solid"
                      fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                    >Profile</Tab>}
                    {profile.id &&
                      <Tab _selected={{ color: "white", bg: "brand.700" }}
                        mt={4}
                        border="2px"
                        borderColor="brand.700"
                        variant="solid"
                        fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                      >Grille Tarif</Tab>
                    }
                  </TabList>
                  <TabPanels>
                    <TabPanel>

                      <div className="column left">
                        <ActiviteSend />
                      </div>
                      <div class="column right">
                      {/* <ListeOutValideTransaction outValidateTransactions={outValidateTransactions}/> */}
                      <ListeOutNoValidateTransaction outNoValidateTransactions={outNoValidateTransactions}/>
                      </div>
                    </TabPanel>
                    <TabPanel>

                      <div className="column left">
                        <ActiviteReceive />
                      </div>

                      <div class="column right">
                      <ListeIntransaction inTransactions={inTransactions}/>
                      </div>
                    </TabPanel>
                    {role &&
                    <TabPanel>
                      <Profil pin={props.pin} getProfile={getProfile} />
                    </TabPanel>
                    }
                    
                    {profile.id &&
                      <TabPanel>
                        <Grille pin={props.pin} profile={profile} />
                      </TabPanel>
                    }
                  </TabPanels>
                </Tabs>
              </Box>
            </Flex>
          </div>
        </div>
      </section>
    </React.Fragment>
  )

}

export default Transaction
