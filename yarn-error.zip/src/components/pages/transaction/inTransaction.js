import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
import{
Box,
Text
} from "@chakra-ui/react";
const ListeIntransaction = (props) => {
  return (
    <>

      <ul>
        {props.inTransactions.map(item => (
          <li key={item.id}>
            <Box 
            borderWidth={1}
            width="full"
            p={2}
            borderRadius={2}
            textAlign="center"
            boxShadow="lg"
            align='center'
            m={2}
            borderColor="brand.700"
            // onClick={() => props.getProfile(item)}
            >
              <Text fontWeight="bold">
                 Vous avez reçu une somme de {item.montant} de {item.expediteur}.
              </Text>
              <Text fontSize="sm">Envoyé le {item.dateEnvoi} et validé le {item.dateReception}</Text>
            </Box>
          </li>
        ))}
      </ul>
    </>
  );
};

export default ListeIntransaction;
