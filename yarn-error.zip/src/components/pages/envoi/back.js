import React, { useState, useContext } from "react";
import {
  Stack,
  Text,
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  ModalFooter,
  ModalHeader,
  Input,
  FormControl,
  FormLabel,
  useDisclosure,
  InputLeftAddon,
  InputRightElement,
  InputGroup,
} from "@chakra-ui/core";
import { MdVpnKey } from "react-icons/md";
import { GlobalContext } from "../../../context/auth-context";
import axios from "axios";
import Footer from "../../header/footer";
const Envoi= () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const passwordRef = React.useRef();
  const montantRef = React.useRef();
  const [showPassword, setShowPassword] = useState(false);

  const context = useContext(GlobalContext);
  const send= async (event) => {
    const phone = context.phone;
    console.log(phone);
    const password = passwordRef.current.value;
    const montant = montantRef.current.value;
    if (password.trim.lenght === 0) {
      return;
    }
    try {
      context.login(phone, password)
      await axios({
        method: "POST",
        url: "http://127.0.0.1:5000/send",
        headers: {
          "Content-Type": "application/json",
          Authorization: `bearer ${context.token}`,
        },
        data: { phone, password, montant },
      })
        .then((res) => {
          if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }

          onClose();
        })
        .catch((err, res) => {
          console.log(err);
        });
    } catch (err) {
      console.log(err);
    }
  };
 const handleClick=(event)=>{
   setShowPassword(!showPassword)
 }
 
  return (
    <>
      <Button
        rightIcon="arrow-forward"
        variant="outline"
        px={3}
        onClick={onOpen}
      >
        Envoi
      </Button>

      <Modal
        initialFocusRef={montantRef}
        isOpen={isOpen}
        onClose={onClose}
        id="password"
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Transaction Envoi</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
          <form onSubmit={send} >
          <FormControl mt={4} isRequired={true}>
            <InputGroup>
              <InputLeftAddon children="XFA" />
              <Input
                type="number"
                placeholder="Montant"
                arial-table="montant"
                ref={montantRef}
                isRequired={true}
              />
            </InputGroup>
          </FormControl>
          <FormControl mt={4} isRequired>
            <InputGroup>
            <InputLeftAddon children={<MdVpnKey />} />
              <Input
                pr="4.5rem"
                type={showPassword ? "text" : "password"}
                placeholder="password"
                arial-table="Password"
                ref={passwordRef}
                
              />
              <InputRightElement width="4.5rem">
                <Button onClick={handleClick}>
                  {showPassword ? "Hide" : "Show"}
                </Button>
              </InputRightElement>
            </InputGroup>
          </FormControl>
          <Button type="submit"  mr={3} mt={4}>
              Valider
            </Button>
            <Button mr={3} mt={4} onClick={onClose}>Annuler</Button>
          </form>
          </ModalBody>
        </ModalContent>
      </Modal>
      <Footer/>
    </>
  );
};

export default Envoi;
