import React, { useState, useContext } from "react";
import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  ModalHeader,
  Input,
  FormControl,
  FormLabel,
  useDisclosure,
  InputLeftAddon,
  InputGroup,
  HStack,
  PinInput,
  PinInputField,
  Box,
  Text,
  useToast
} from "@chakra-ui/react";
import { GlobalContext } from "../../../context/auth-context";
import axios from "axios";
import BigInt from "big-integer"
import CryptoJS from "crypto-js"
import QRCode from "react-qr-code";
const Envoi = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const montantRef = React.useRef();
  const destPhoneRef = React.useRef();
  const [data, setData] = useState({ telephoneDest: null, montant: 0, code: null });
  const [transaction, setTransaction] = useState({});
  const [pin, setPin] = useState(null);
  const [pinValidation, setPinValidation] = useState(true);
  const context = useContext(GlobalContext);
  const toast = useToast()
  const openPin = (event) => {
    const destPhone = destPhoneRef.current.value;
    const montant = montantRef.current.value;
    const code = BigInt.randBetween("1e3", "1e4")
    setData({ ...data, telephoneDest: destPhone, montant: montant, code: code.toString() })
    event.preventDefault();
    onOpen()
  }

  const fraistransaction= async (event) => {
    event.preventDefault()
    const P = BigInt(CryptoJS.SHA256(pin), 16)
    try {
      const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)
      const dataSend = context.encrypt(dataSK.SK, context.IV, {montant: data.montant})
      axios.post("/fraistransfert" ,{ data: dataSend })
        .then((res) => {
        
          
          if (res.status !== 900 &&res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }

          return res.data
        }).then((dataRecieve) => {
          const dataResponse = context.decrypt(dataSK.SK, context.IV, dataRecieve.response)
          if (dataResponse.code!==100){
            toast({
              title: "Information",
              description: dataResponse.message,
              status: "warning",
              duration: 9000,
              isClosable: true,
              position: "top",
          })
          setData({...data, telephoneDest: "", montant: 0, code: null })
  
          onClose()
          }
          else {
          setData({...data, montant: dataResponse.montant})
          setPinValidation(!pinValidation)
        }
        })
        .catch((err, res) => {

          console.log(err);
        });
    } catch (err) {
      console.log(err);
    }
  };
  const send = async (event) => {
    event.preventDefault()
    const P = BigInt(CryptoJS.SHA256(pin), 16)
    try {
      const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)
      const dataSend = context.encrypt(dataSK.SK, context.IV, data)
      axios.post("/stransfert" ,{ data: dataSend })
        .then((res) => {
          if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }
          return res.data
        }).then((data) => {
          const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
            toast({
              title: "Information",
              description: dataResponse.message,
              status: "success",
              duration: 9000,
              isClosable: true,
              position: "top",
          })

        })
        .catch((err, res) => {

          console.log(err);
        });
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <>
      <Box my={1}
         width="full"
         textAlign="left" 
         boxShadow="lg"
         p={4}
        >

        <form onSubmit={openPin}>
          <FormControl mt={4} isRequired >
            <FormLabel  >Téléphone Destinataire</FormLabel>
            <InputGroup>

              <InputLeftAddon children="+221" />
              <Input
                type="tel"
                value={data.telephoneDest}
                onChange={(e)=>setData({...data, telephoneDest:e.target.value})}
                placeholder="Téléphone"
                arial-table="phone"
                ref={destPhoneRef}
              />
            </InputGroup>
          </FormControl>
          <FormControl mt={4} isRequired>
            <FormLabel>Montant</FormLabel>
            <InputGroup>

              <InputLeftAddon children="XFA" />
              <Input
                type="number"
                value={data.montant}
                placeholder="Montant"
                arial-table="montant"
                onChange={(e)=>setData({...data, montant:e.target.value})}
                ref={montantRef}
              />
            </InputGroup>
          </FormControl>
          <Button
            width="full"
            mt={4}
            border="2px"
            borderColor="brand.700"
            variant="solid"
            background="brand.700"
            color="white"
            type="submit"
          >
            Valider transfert
      </Button>

        </form>

      </Box>

      <Modal
        isOpen={isOpen}
        onClose={onClose}
        id="pin"
        size="xs"
      >
        <ModalOverlay />
        {pinValidation ?
          <ModalContent>
            <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box></ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>

              <form onSubmit={fraistransaction}>
                <Box
                  borderWidth={1}
                  width="full"
                  p={4}
                  borderRadius={4}
                  boxShadow="lg"
                  textAlign="center"
                  alignContent="center"
                >
                  <FormControl mt={4} isRequired>
                    <HStack align="center">
                      <PinInput
                        onComplete={(value) => setPin(value)}
                        mask>
                        <PinInputField />
                        <PinInputField />
                        <PinInputField />
                        <PinInputField />
                      </PinInput>
                    </HStack>

                  </FormControl>
                </Box>
                <HStack mt={4}>
                  <Button
                    border="2px"
                    borderColor="brand.700"
                    variant="solid"
                    background="brand.700"
                    color="white"
                    width="full"
                    mr={3}
                    type="submit"
                  >
                    Frais transaction
            </Button>
                  <Button
                    border="2px"
                    borderColor="brand.700"
                    variant="solid"
                    background="brand.700"
                    color="white"
                    width="full"
                    mr={3}
                    onClick={()=>{ setData({...data, telephoneDest: "", montant: 0, code: null });onClose()}}>Annuler</Button>
                </HStack>
              </form>
            </ModalBody>
          </ModalContent> :
          <ModalContent>
            <ModalHeader color="brand.700">Transaction</ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>

              <Box>
                <HStack align="center">
                <Box p={2}>
                  <Text>
                  Code: {data.code}
                  </Text>
                  <Text>
                  Montant: {data.montant}
                  </Text>               
                </Box>
                </HStack>
                <Button
                  border="2px"
                  borderColor="brand.700"
                  variant="solid"
                  background="brand.700"
                  color="white"
                  variant="outline"
                  width="full"
                  mr={3}
                  onClick={(event) => { send(event); setPinValidation(!pinValidation);setData({...data, telephoneDest: "", montant: 0, code: null }); onClose() }}
                >
                  Valider
            </Button>
              </Box>

            </ModalBody>
          </ModalContent>
        }
      </Modal>
    </>
  );
};

export default Envoi
