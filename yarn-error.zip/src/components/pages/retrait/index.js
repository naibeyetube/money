import React, { useState, useContext } from "react";
import {

  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,

  ModalHeader,
  Input,
  FormControl,
  FormLabel,
  useDisclosure,
  InputLeftAddon,
  InputRightElement,
  InputGroup,
  HStack,
  PinInput,
  PinInputField,
  Box,

} from "@chakra-ui/react";

import { GlobalContext } from "../../../context/auth-context";
import axios from "axios";
import BigInt from "big-integer"
import CryptoJS from "crypto-js"
import QRCode from "react-qr-code";
const Retrait = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const montantRef = React.useRef();
  const [data, setData] = useState({ montant: "", code: "" });
  const [transaction, setTransaction] = useState({});
  const [pin, setPin] = useState(null);
  const [pinValidation, setPinValidation] = useState(true);
  const context = useContext(GlobalContext);
  const openPin = (event) => {
    event.preventDefault();
    const montant = montantRef.current.value;
    setData({ ...data, montant: montant })
    onOpen()
  }
  const send = async (event) => {
    event.preventDefault()
    const P = BigInt(CryptoJS.SHA256(pin), 16)
    try {
      const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)
      const dataSend = context.encrypt(dataSK.SK, context.IV, data)
      await axios.post("/createuser", { data: dataSend})
      .then((res) => {
          if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }
          return res.data
        }).then((data) => {
          const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
          setPinValidation(!pinValidation)


        })
        .catch((err, res) => {

          console.log(err);
        });
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <>
      <Box my={1}
        width="full"
        textAlign="left"
        boxShadow="lg"
        p={4}
      >
        <form onSubmit={openPin}>
              <FormControl mt={4} isRequired>
                <FormLabel>Code Transfert</FormLabel>
                <PinInput
                  onChange={(value) => setData({ ...data, code: value })}
                  mask>
                  <PinInputField />
                  <PinInputField />
                  <PinInputField />
                  <PinInputField />
                </PinInput>
              </FormControl>
              <FormControl mt={4} isRequired>
            <FormLabel>Montant</FormLabel>
            <InputGroup>

              <InputLeftAddon children="XFA" />
              <Input
                type="number"
                placeholder="Montant"
                arial-table="montant"
                ref={montantRef}
              />
            </InputGroup>
          </FormControl>

            <Button
              my={4}
              width="full"
              border="2px"
              borderColor="brand.700"
              variant="solid"
              background="brand.700"
              color="white"
              type="submit"
            >
              Valider transaction
        </Button>
        </form>

      </Box>

      <Modal
        isOpen={isOpen}
        onClose={onClose}
        id="pin"
        size="xs"
      >
        <ModalOverlay />
        {pinValidation ?
          <ModalContent>
            <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box>
                    </ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>

              <form onSubmit={send}>
                <Box
                  borderWidth={1}
                  width="full"
                  p={4}
                  borderRadius={4}
                  boxShadow="lg"
                  textAlign="center"
                  alignContent="center"
                >
                  <FormControl mt={4} isRequired>
                    <HStack align="center">
                      <PinInput
                        onComplete={(value) => setPin(value)}
                        mask>
                        <PinInputField />
                        <PinInputField />
                        <PinInputField />
                        <PinInputField />
                      </PinInput>
                    </HStack>

                  </FormControl>
                </Box>
                <HStack mt={4}>
                  <Button
                    border="2px"
                    borderColor="brand.700"
                    variant="solid"
                    background="brand.700"
                    color="white"
                    width='full'
                    mr={3}
                    type="submit"
                  >
                    Valider
            </Button>
                  <Button
                    border="2px"
                    borderColor="brand.700"
                    variant="solid"
                    background="brand.700"
                    color="white"
  
                    mr={3}
                    width='full'
                    onClick={onClose}>Annuler</Button>
                </HStack>
              </form>
            </ModalBody>
          </ModalContent> :
          <ModalContent>
            <ModalHeader color="brand.700">Transaction</ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>

              <Box>
                <HStack align="center">
                  <Box>
                    <QRCode value={JSON.stringify(data)} />
                  </Box>
                </HStack>
                <Button
                  border="2px"
                  borderColor="brand.700"
                  variant="solid"
                  background="brand.700"
                  color="white"
                  mr={3}
                  onClick={() => { setPinValidation(!pinValidation); setData({...data, montant: 0, code: "" }); onClose() }}
                >
                  Quitter
            </Button>
              </Box>

            </ModalBody>
          </ModalContent>
        }
      </Modal>
    </>
  );
};

export default Retrait
