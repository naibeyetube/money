import React, { Component } from "react";
import { Redirect } from 'react-router-dom';

import {
  Box,
  FormControl,
  Input,
  Button,
  InputLeftAddon,
  InputGroup,
  FormLabel,
  HStack,
  PinInput,
  PinInputField,
  Heading
} from "@chakra-ui/react";
import { GlobalContext } from "../../../context/auth-context";
import Header from "../../header/header";
import Footer from "../../header/footer";
import BgImg from "../../../assets/images/wallet.svg"
import "../../../App.css"


export default class login extends Component {
  render() {
    return (
      <div>
        <Header />
        <section className="about" id="about">
          <div className="max-width">

            <div className="about-content">
              <div className="column left">
                <img src={BgImg} alt="Logo" />
              </div>
              <div class="column right">
                <Box
                  borderWidth={1}
                  width="full"
                  maxWidth="400px"
                  p={4}
                  borderRadius={4}
                  textAlign="center"
                  boxShadow="lg"
                  align='center'
                  my="20%"
                >
                  <Box >
                  <Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                      borderColor="brand.700"
                    >
                        Connexion
   
                    </Box>
                    <LoginForm />
                  </Box>
                </Box>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  }
}

class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPassword: false,
      redirect: false,
      pin: null
    };
    this.motPasseEl = React.createRef();
    this.telephoneEl = React.createRef();
  }
  static contextType = GlobalContext;

  photoSelectedHandle = (event) => {
    this.setState({ photo: event.target.files[0] });
  };
  handleClickPassword = () => this.setState({ showPassword: !this.state.showPassword });
  submitHandler = (event) => {
    event.preventDefault();
    const motPasse = this.motPasseEl.current.value;
    const telephone = this.telephoneEl.current.value;
    const code = this.context.login(telephone, motPasse, this.state.pin)
    if (code === 200) {
      this.setState({ redirect: true })
    }

  };
  render() {
    if (this.context.dataSK) {
      return <Redirect to="/cash" />
    }
    return (
      <Box my="{1}" textAlign="left">
        <form onSubmit={this.submitHandler}>
          <FormControl id="telephone" isRequired>
            <FormLabel>Téléphone</FormLabel>
            <Input type="text"
              placeholder="Entrer votre téléphone"
              arial-table="telephone"
              ref={this.telephoneEl} />
          </FormControl>
          <FormControl id="password" mt={4} isRequired>
            <FormLabel>Mot de passe</FormLabel>
            <InputGroup>
              <Input
                pr="4.5rem"
                type={this.state.showPassword ? "text" : "password"}
                placeholder="Entrer votre mot de passe"
                arial-table="password"
                ref={this.motPasseEl}
              />
            </InputGroup>
          </FormControl>
          <FormControl mt={4} isRequired>
            <FormLabel>

             Session PIN
              
              </FormLabel>
            <HStack align="center">
              <PinInput
                onComplete={(value) => this.setState({ pin: value })}
                mask>
                <PinInputField />
                <PinInputField />
                <PinInputField />
                <PinInputField />
              </PinInput>
            </HStack>

          </FormControl>
          <Button
            m={2}
            border="2px"
            width="full"
            background="brand.700"
            color="white"
            type='submit'

          >
            VALIDER
            </Button>
        </form>

      </Box>
    );
  }
}
