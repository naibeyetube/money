import React, { useState, useEffect,useContext } from "react";
import axios from "axios";
import ReactDataGrid from "react-data-grid";
import { Toolbar, Data, Filters} from "react-data-grid-addons";
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
const {
  NumericFilter,
  AutoCompleteFilter,
  MultiSelectFilter,
  SingleSelectFilter,
} = Filters;
const columns = [

  {
    key: "intitule",
    name: "Profil",
    sortable: true,
    filterable: true,
    width: 170,
  },
  {
    key: "abreviation",
    name: "Abréviation",
    sortable: true,
    filterable: true,
    width: 130,
  },
  {
    key: "plafondsolde",
    name: "Plafond Solde",
    sortable: true,
    filterable: true,
    width: 150,
  },

];
const selectors = Data.Selectors;
const handleFilterChange = (filter) => (filters) => {
  const newFilters = { ...filters };
  if (filter.filterTerm) {
    newFilters[filter.column.key] = filter;
  } else {
    delete newFilters[filter.column.key];

  }
  return newFilters;
};
function getValidFilterValues(rows, columnId) {
  return rows
    .map(r => r[columnId])
    .filter((item, i, a) => {
      return i === a.indexOf(item);
    });
}

function getRows(rows, filters) {
  return selectors.getRows({ rows, filters });
}
const ListeProfile = (props) => {
  const [profiles, setProfiles] = useState([]);
  const [filters, setFilters] = useState({});
  const context = useContext(GlobalContext);
  const filteredRows = getRows(profiles, filters);
  const sortRows = (initialRows, sortColumn, sortDirection) => (rows) => {
    const comparer = (a, b) => {
      if (sortDirection === "ASC") {
        return a[sortColumn] > b[sortColumn] ? 1 : -1;
      } else if (sortDirection === "DESC") {
        return a[sortColumn] < b[sortColumn] ? 1 : -1;
      }
    };
    return sortDirection === "NONE" ? initialRows : [...rows].sort(comparer);
  };
    const selectedProfile = (rowIdx, row) => {
    const liste=row
    props.getProfile({...liste})
    }
    useEffect(async() => {
      const P = BigInt(CryptoJS.SHA256(props.pin), 16)
      const SK = await sessionStorage.getItem('dataSK');
      const dataSK=await context.decrypt(context.KDF(P, context.IV, 32), context.IV, SK)      
      await axios({
        method: "GET",
        url: "/profile",
    }).then((res) => {
        if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
        }
        return res.data
    }).then((data)=>{
      const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
      setProfiles([...dataResponse]);
    })
    }, []); 

  return (
    <ReactDataGrid
      columns={columns}
      rowGetter={(i) => filteredRows[i]}
      rowsCount={filteredRows.length}
      minWidth={450}
      minHeight={270}
      toolbar={<Toolbar enableFilter={true} />}
      onAddFilter={(filter) => setFilters(handleFilterChange(filter))}
      onClearFilters={() => {setFilters({})}}
      getValidFilterValues={columnKey => getValidFilterValues(profiles, columnKey)}
      onGridSort={(sortColumn, sortDirection) =>
        {setProfiles(sortRows(filteredRows, sortColumn, sortDirection));
        }
      }
      onRowClick={selectedProfile}
    />
  );
};

export default ListeProfile;
