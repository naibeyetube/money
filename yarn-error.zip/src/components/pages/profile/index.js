import React, { useState } from "react";
import ProfilForm from './form'
import { Box } from "@chakra-ui/react";
import ListeProfile from "./list";
const Profile = (props) => {
  const [profile, setProfile] = useState({})
  const [pin, setPin]=useState(props.pin)
  const getProfile = (item) => {
    setProfile({ ...item })
    props.getProfile(item)

  }
  const getPin = (item) => {
    setPin(item)

  }

  return (
    <>
      <div className="column left">
      <Box my={1}
         width="full"
         textAlign="left" 
         boxShadow="lg"
         p={4}
        >
        <ProfilForm profile={profile}  getPin={getPin} getProfile={getProfile}/>
        </Box>
      </div>
      <div class="column right">
        <Box my={1}
         width="full"
         textAlign="left" 
         boxShadow="lg"
         p={4}

        >
        <ListeProfile pin={props.pin} getProfile={getProfile} profile={profile}/>
        </Box>
      </div>
    </>
  )
}
export default Profile
