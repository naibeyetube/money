import React, { Component, useState, useEffect, useContext } from "react";
import {
    Box,
    FormControl,
    Input,
    Button,
    FormLabel,
    Heading,
    Divider,
    useToast,
    Modal,
    ModalBody,
    ModalCloseButton,
    ModalContent,
    ModalOverlay,
    ModalFooter,
    ModalHeader,
    useDisclosure,
    HStack,
    PinInput,
    PinInputField,
    NumberInput,
    NumberInputField,
    Tabs, TabList, TabPanels, Tab, TabPanel,
} from "@chakra-ui/react";
import axios from "axios";
import { Redirect } from 'react-router-dom';
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
import "../../../App.css"

const ProfileForm = (props) => {
    const intituleEl = React.createRef();
    const abreviationEl = React.createRef();
    const conditionEl = React.createRef();
    const seuiljourEl = React.createRef();
    const seuilsemaineEl = React.createRef();
    const seuilmoisEl = React.createRef();
    const plafondsoldeEl = React.createRef();
    const [profile, setProfile] = useState({ id: "", intitule: "", abreviation: "", condition: "", seuiljour: 0, seuilsemaine: 0, seuilmois: 0, plafondsolde: 0 })
    const [pin, setPin] = useState("")
    const [deleteItem, setDeleteItem]=useState(false)
    const context = useContext(GlobalContext);
    const { isOpen, onOpen, onClose } = useDisclosure();
    const toast = useToast()
    const openPin = (event) => {
        event.preventDefault();
        onOpen()
    }
    const submitHandler = async (event) => {
        event.preventDefault();
        const P = BigInt(CryptoJS.SHA256(pin), 16)
        const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)
        const dataSend = context.encrypt(dataSK.SK, context.IV, profile)
        if (profile.id) {
            try {

                await axios.put("http://react.naibeyedigit.net/money/profile", { data: dataSend}).then((res) => {
                    const dataResponse = context.decrypt(dataSK.SK, context.IV, res.data.response)

                    props.getPin(pin)
                    setPin("")
                    props.getProfile(dataResponse)
                    setProfile({ id: "", intitule: "", abreviation: "", condition: "", seuiljour: 500, seuilsemaine: 500, seuilmois: 500, plafondsolde: 500 })
                    toast({
                        title: "Mise à jour.",
                        description: res.data.message,
                        status: "success",
                        duration: 9000,
                        isClosable: true,
                        position: "top",
                    })

                });
            } catch (e) {
                console.log(e)
            }
        }
        else {

            await axios({
                method: "POST",
                url: "/profile",
                data: { data: dataSend }
            }).then((res) => {
                if (res.status !== 200 && res.status !== 201) {
                    throw new Error("Failed");
                }
                return res.data
            }).then((data) => {
                const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
                props.getPin(pin)
                setPin("")               
                props.getProfile(dataResponse)
                setProfile({ id: "", intitule: "", abreviation: "", condition: "", seuiljour: 500, seuilsemaine: 500, seuilmois: 500, plafondsolde: 500 })
                toast({
                    title: "Ajout",
                    description: data.message,
                    status: "success",
                    duration: 9000,
                    isClosable: true,
                    position: "top",
                })

            });
        }
    };
    const format = (val) => `XFA ` + val
    const parse = (val) => val.replace(/^\$/, "")

    const deleteHandle = async () => {
        await axios.delete(`/profile/${profile.id}`).then((res) => {

            // props.getprofile(res.data.Profile)
            toast({
                title: "Suppression.",
                description: res.data.message,
                status: "success",
                duration: 9000,
                isClosable: true,
                position: "top",
            })

        });
        setPin("")
        setProfile({ id: "", intitule: "", abreviation: "", condition: "", seuiljour: 500, seuilsemaine: 500, seuilmois: 500, plafondsolde: 500 })

    }
    useEffect(() => {
        setProfile({ ...props.profile })
    }, [props.profile]);
    return (
        <>
            <Box my={1} textAlign="center">
                <Heading as="h2" size="md" color="brand.700" textAlign="center">
                    PROFILE FORMULAIRE
            </Heading>
                <Divider orientation="horizontal" m={2} />
                <form onSubmit={openPin}>
                    <Tabs
                        variant="enclosed" borderRadius={4}
                        fontSize={{ base: "10px", md: "16px", lg: "16px" }}
                        align='center'
                    >
                        <TabList>
                            <Tab _selected={{ color: "white", bg: "brand.700" }}
                                mt={4}
                                border="2px"
                                borderColor="brand.700"
                                variant="solid"
                                fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                            >Informations générales</Tab>
                            <Tab _selected={{ color: "white", bg: "brand.700" }}
                                mt={4}
                                border="2px"
                                borderColor="brand.700"
                                variant="solid"
                                fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                            >Seuil transaction</Tab>
                        </TabList>
                        <TabPanels>
                            <TabPanel>
                                <FormControl id="intitule" isRequired>
                                    <FormLabel>Intitulé</FormLabel>
                                    <Input type="text"
                                        value={profile.intitule}
                                        onChange={(e) => { setProfile({ ...profile, intitule: e.target.value }) }}
                                        placeholder="Entrer l'intitulé'"
                                        arial-table="code"
                                        ref={intituleEl} />
                                </FormControl>
                                <FormControl id="abreviation" isRequired>
                                    <FormLabel>Abréviation</FormLabel>
                                    <Input type="text"
                                        value={profile.abreviation}
                                        onChange={(e) => { setProfile({ ...profile, abreviation: e.target.value }) }}
                                        placeholder="Entrer l'abréviation"
                                        arial-table="code"
                                        ref={abreviationEl} />
                                </FormControl>

                                <FormControl id="condition" isRequired>
                                    <FormLabel>condition</FormLabel>
                                    <Input type="text"
                                        value={profile.condition}
                                        onChange={(e) => { setProfile({ ...profile, condition: e.target.value }) }}
                                        placeholder="Entrer l'abréviation de la spécialité"
                                        arial-table="code"
                                        ref={conditionEl} />
                                </FormControl>
                            </TabPanel>
                            <TabPanel>
                            <FormControl id="seuiljour" isRequired>
                        <FormLabel>Seuil journalier</FormLabel>
                        <NumberInput
                            onChange={(value) => { setProfile({ ...profile, seuiljour:value }) }}
                            arial-table="code"
                            ref={seuiljourEl}
                            value={profile.seuiljour}
                            min={500}

                        >
                            <NumberInputField />
                        </NumberInput>
                    </FormControl>
                    <FormControl id="seuilsemaine" isRequired>
                        <FormLabel>Seuil hebdomadaire</FormLabel>
                        <NumberInput
                            onChange={(value) => { setProfile({ ...profile, seuilsemaine: value }) }}
                            arial-table="code"
                            ref={seuilsemaineEl}
                            value={profile.seuilsemaine}
                        >
                            <NumberInputField />
                        </NumberInput>
                    </FormControl>
                    <FormControl id="seuiljour" isRequired>
                        <FormLabel>Seuil mensuel</FormLabel>
                        <NumberInput
                            onChange={(value) => { setProfile({ ...profile, seuilmois: value }) }}
                            arial-table="code"
                            ref={seuilmoisEl}
                            value={profile.seuilmois}
                        >
                            <NumberInputField />
                        </NumberInput>
                    </FormControl>
                    <FormControl id="plafondsolde" isRequired>
                        <FormLabel>Plafond Solde</FormLabel>
                        <NumberInput
                            onChange={(value) => { setProfile({ ...profile, plafondsolde: value }) }}
                            arial-table="code"
                            ref={plafondsoldeEl}
                            value={profile.plafondsolde}
                            defaultValue={500}
                        >
                            <NumberInputField />
                        </NumberInput>
                    </FormControl>
                            </TabPanel>
                        </TabPanels>
                    </Tabs>

                    
                    <Button
                        m={2}
                        border="2px"
                        background="brand.700"
                        color="white"
                        type='submit'

                    >
                        {profile.id ? "Mettre à jour" : "Valider"}
                    </Button>
                    <Button
                        m={2}
                        border="2px"
                        background="brand.700"
                        color="white"
                        isDisabled={profile.id && !deleteItem? false : true}
                        onClick={(event)=>{openPin(event); if(pin) deleteHandle()}}

                    >
                        Supprimer
            </Button>
                </form>

            </Box>
            <Modal
                isOpen={isOpen}
                onClose={onClose}
                id="pin"
                size="xs"
            >
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box>
                    </ModalHeader>
                    <ModalCloseButton />
                    <ModalBody pb={6}>

                        <form onSubmit={submitHandler}>
                            <Box
                                borderWidth={1}
                                width="full"
                                p={4}
                                borderRadius={4}
                                boxShadow="lg"
                                textAlign="center"
                                alignContent="center"
                            >
                                <FormControl mt={4} isRequired>
                                    <HStack align="center">
                                        <PinInput
                                            onChange={(value) => { setPin(value) }}
                                            mask>
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                        </PinInput>
                                    </HStack>

                                </FormControl>
                            </Box>
                            <HStack mt={4}>
                                <Button
                                    border="2px"
                                    borderColor="brand.700"
                                    variant="solid"
                                    background="brand.700"
                                    color="white"
                                    variant="outline"
                                    mr={3}
                                    type="submit"
                                    onClick={onClose}>
                                    Valider
                                </Button>

                            </HStack>
                        </form>

                    </ModalBody>
                </ModalContent>
            </Modal>
        </>
    );
}
export default ProfileForm