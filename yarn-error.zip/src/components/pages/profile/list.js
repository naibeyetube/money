import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
import{
Box,
Text
} from "@chakra-ui/react";
const ListeProfile = (props) => {
  const [profiles, setProfiles] = useState([]);
  const context = useContext(GlobalContext);
  useEffect(async () => {
    const P = BigInt(CryptoJS.SHA256(props.pin), 16)

    const SK = await sessionStorage.getItem('dataSK');
    const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, SK)
    await axios.get("/profile").then((res) => {
      if (res.status !== 200 && res.status !== 201) {
        throw new Error("Failed");
      }
      return res.data
    }).then((data) => {
      const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
      setProfiles([...dataResponse]);
    })
  }, [props.profile, props.pin]);

  return (
    <>

      <ul>
        {profiles.map(item => (
          <li key={item.id}>
            <Box 
            borderWidth={1}
            width="full"
            p={2}
            borderRadius={2}
            textAlign="center"
            boxShadow="lg"
            align='center'
            m={2}
            borderColor="brand.700"
            onClick={() => props.getProfile(item)}>
              <Text fontWeight="bold">
                {item.intitule}
              </Text>
              <Text fontSize="sm">Plafond solde: {item.plafondsolde} XFA</Text>
            </Box>
          </li>
        ))}
      </ul>
    </>
  );
};

export default ListeProfile;
