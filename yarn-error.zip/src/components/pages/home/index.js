import React, { Component, useState, useRef, useContext, useEffect } from "react";
import Header from "../../header/header";
import { Redirect } from 'react-router-dom';
import { GlobalContext } from "../../../context/auth-context";
import BgImg from "../../../assets/images/bg.svg"
import image1 from '../../../images/recrutement.jpg';

import bio from '../../../images/bio.jpg';
import energie from '../../../images/energie.jpg';
import mecaniques from '../../../images/mecaniques.jpg';
import reseaux from '../../../images/reseaux.jpg';
import electrique from '../../../images/electrique.jpg';
import elevage from '../../../images/elevage.jpg';
import informatique from '../../../images/informatique.jpg';
import Footer from "../../header/footer";
import esso from '../../../images/esso.png';
import geyser from '../../../images/geyser.png';
import ndjamena from '../../../images/ndjamena.png';
import ucad from '../../../images/ucad.png';

const Home = (props) => {
  const context = useContext(GlobalContext)
  useEffect(async () => {
    // setIsLoading(false);
    if (!context.dataSK) {
    const SK = await sessionStorage.getItem('dataSK');
    if (SK) {
        context.retrieve()
    }
    }
    
  if (!context.dataSK) {
    return <Redirect to="/login" />
}
  })
  return (
    <div>
      <div>
        <Header />
        <section className="home" id="home">
          <div className="max-width">
            <div className="home-content">

                <div className="text-1">Hi, </div>
                <div className="text-2">Soyez le bienvenu! </div>
            </div>
          </div>
        </section>
        <section class="about" id="about">
          <div class="max-width">
            <h2 class="title">About me</h2>
            <div class="about-content">
              <div class="column left">
                <img src={BgImg} alt="Logo" />
              </div>
              <div class="column right">
                
              </div>
            </div>
          </div>
        </section>
        <section className="service" id="services">
        <div className="max-width">
          <h2 className="title">Nos services digitaux</h2>
          <div className="carousel1 owl-carousel">
            <div className="card">
              <div className="box">
                <div>
                  <img src={informatique} alt="" />
                </div>
                <div className="text">Génie Informatique</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={electrique} alt="" />
                </div>
                <div className="text">Génie Electrique</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <div>
                    <img src={mecaniques} alt="" />
                  </div>
                </div>
                <div className="text">Génie Mécanique</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={energie} alt="" />
                </div>
                <div className="text">Génie énergétique</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={reseaux} alt="" />
                </div>
                <div className="text">Réseaux et Téclécommunications</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={elevage} alt="" />
                </div>
                <div className="text">Science et Technique d'élevage</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={bio} alt="" />
                </div>
                <div className="text">Science biomédicale et pharmacie</div>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rem quia sunt, quasi quo illo enim.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="info" id="info">
        <div className="max-width">
          <h2 className="title">Actualités</h2>
          <div className="info-content">
            <div className="column left">
              <div>
                <img src={image1} alt="" />
              </div>
            </div>
            <div className="column right">
              <div className="text">Avis de recrutement</div>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi ut voluptatum eveniet doloremque autem excepturi eaque, sit laboriosam voluptatem nisi delectus. Facere explicabo hic minus accusamus alias fuga nihil dolorum quae. Explicabo illo unde, odio consequatur ipsam possimus veritatis, placeat, ab molestiae velit inventore exercitationem consequuntur blanditiis omnis beatae. Dolor iste excepturi ratione soluta quas culpa voluptatum repudiandae harum non.</p>
              <a href="#">Présentation</a>
            </div>
          </div>
        </div>
      </section>
      
                <section class="teams" id="teams">
                    <div class="max-width">
                        <h2 class="title">Mon équipe</h2>
                        <div class="carousel  owl-carousel">
                            <div class="card">
                                <div class="box">
                                    <img src={BgImg} alt="Logo" />
                                    <div class="text">Someone name</div>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </div>
                            </div>
                            <div class="card">
                                <div class="box">
                                    <img src={BgImg} alt="Logo" />
                                    <div class="text">Someone name</div>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </div>
                            </div>
                            <div class="card">
                                <div class="box">
                                    <img src={BgImg} alt="Logo" />
                                    <div class="text">Someone name</div>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </div>
                            </div>

                        </div>

                        
                    </div>
                </section>
                <section className="cooperation" id="cooperation">
        <div className="max-width">
          <h2 className="title">Partenariats</h2>
          <div className="carousel owl-carousel">
            <div className="card">
              <div className="box">
                <div>
                  <img src={esso} alt="" />
                </div>
                <div className="text">USA</div>
                <p>ExxonMobil</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={geyser} alt="" />
                </div>
                <div className="text">TCHAD</div>
                <p>Geyser</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={ucad} alt="" />
                </div>
                <div className="text">SENEGAL</div>
                <p>Université Cheikh Anta Diop de Dakar</p>
              </div>
            </div>
            <div className="card">
              <div className="box">
                <div>
                  <img src={ndjamena} alt="" />
                </div>
                <div className="text">TCHAD</div>
                <p>Université de ndjamena</p>
              </div>
            </div>
          </div>
        </div>
        <section className="contact" id="contact">
        <div className="max-width">
          <h2 className="title">Contact</h2>
          <div className="contact-content">
            <div className="column left">
              <div className="text">Nos coordonnées</div>
              <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos harum corporis fuga corrupti. Doloribus quis soluta nesciunt veritatis vitae nobis?</p>
              <div className="icons">
                <div className="row">
                  <i className="fas fa-user"></i>
                  <div className="info">
                    <div className="head">Sécrétariat</div>
                    <div className="sub-title">Rakhié</div>
                  </div>
                </div>
                <div className="row">
                  <i className="fas fa-map-marker-alt"></i>
                  <div className="info">
                    <div className="head">Addresse</div>
                    <div className="sub-title">B.P. 6077, Abéché</div>
                  </div>
                </div>
                <div className="row">
                  <i className="fas fa-envelope"></i>
                  <div className="info">
                    <div className="head">Email</div>
                    <div className="sub-title">info@insta.td</div>
                  </div>
                </div>
                <div className="row">
                  <i className="fas fa-phone"></i>
                  <div className="info">
                    <div className="head">Phone</div>
                    <div className="sub-title">+235 66 29 05 45</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="column right">
              <div className="text">Message me</div>
              <form action="#">
                <div className="fields">
                  <div className="field name">
                    <input type="text" placeholder="Name" required />
                  </div>
                  <div className="field email">
                    <input type="email" placeholder="Email" required />

                  </div>
                </div>
                <div className="field">
                  <input type="text" placeholder="Subject" required />

                </div>
                <div className="field textarea">
                  <textarea cols="30" rows="10" placeholder="Message.." required></textarea>

                </div>
                <div className="button">
                  <button type="submit">Envoyer message</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

                </section>
        <Footer />
      </div>
    </div>
  );
}
export default Home