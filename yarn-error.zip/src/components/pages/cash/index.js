import React, { useState, useRef, useContext, useEffect } from "react";
import CryptoJS from "crypto-js"
import Header from "../../header/header";
import {Redirect} from 'react-router-dom';
import {GlobalContext} from "../../../context/auth-context";
import Transaction from "../transaction";
import Footer from "../../header/footer";
import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  ModalFooter,
  ModalHeader,
  useDisclosure,
  HStack,
  PinInput,
  PinInputField,
  FormControl,
  Box

} from "@chakra-ui/react";
import BigInt from "big-integer"
 const Cash =(props)=> {
   const context = useContext(GlobalContext)
   const { isOpen, onOpen, onClose } = useDisclosure();
   const [pin, setPin]=useState("")
   const [redirect, setRedirect]=useState(false)
   const [user, setUser] = useState({})
   const [expired, setExpired] = useState(true)
   const validate=async (event)=>{
    event.preventDefault()
     try{
      const P=BigInt(CryptoJS.SHA256(pin),16)
      const SK = await sessionStorage.getItem('dataSK');
      const dataSK=await context.decrypt(context.KDF(P, context.IV, 32), context.IV, SK)
      const user = await sessionStorage.getItem('dataUser');
      const dataUser=await context.decrypt(context.KDF(P, context.IV, 32), context.IV, user)
      setUser({...dataUser})
       context.retrieve()
       setRedirect(!redirect)
       setExpired(!expired)
       onClose()
     }catch(err){
      console.log(err)
    };
   }
   useEffect(async () => {
     // setIsLoading(false);
     const SK =await sessionStorage.getItem('dataSK');
      if (SK && !redirect) {
          onOpen()        
      }
      else
       return <Redirect to="/login" />
 } )
    return (
      
      <div>
        <div>
          <Header/>
          {redirect && <Transaction dataUser={user} pin={pin}/>}
          <Footer/>
        </div>
        <Modal
        isOpen={isOpen}
        onClose={onClose}
        id="pin"
        size="xs"
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box></ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>

            <form onSubmit={validate}>
              <Box
                borderWidth={1}
                width="full"
                p={4}
                borderRadius={4}
                boxShadow="lg"
                textAlign="center"
                alignContent="center"
              >
                <FormControl mt={4} isRequired>
                  <HStack align="center">
                    <PinInput 
                    onChange={( value)=>{setPin(value)}}
                    mask>
                      <PinInputField />
                      <PinInputField />
                      <PinInputField />
                      <PinInputField />
                    </PinInput>
                  </HStack>

                </FormControl>
              </Box>
              <HStack mt={4}>
                <Button
                  border="2px"
                  borderColor="brand.700"
                  variant="solid"
                  background="brand.700"
                  color="white"
                  mr={3}
                  type="submit"
                  width="full"
                  onClick={onClose}>
                  Valider
            </Button>
            {  redirect?
                <Button
                  border="2px"
                  borderColor="brand.700"
                  variant="solid"
                  background="brand.700"
                  color="white"
                  mr={3}
                  onClick={onClose}>Acceder </Button>
                  :
                  ""
                }
              </HStack>
            </form>

          </ModalBody>
        </ModalContent>
      </Modal>
      </div>
    );
}
export default Cash