import React, { Component } from "react";
import {
  Box,
  FormControl,
  Input,
  Button,
  InputGroup,
  InputRightAddon,
  FormLabel,
  Heading

} from "@chakra-ui/react";
import { Redirect } from 'react-router-dom';
import { GlobalContext } from "../../../context/auth-context";
import Header from "../../header/header";
import Footer from "../../header/footer";
import BgImg from "../../../assets/images/transfert.svg"
import "../../../App.css"
export default class registration extends Component {
  render() {
    return (
      <>
        <Header />
        <section className="about" id="about">
          <div className="max-width">

            <div className="about-content">
              <div class="column left">
                <img src={BgImg} alt="Logo" />
              </div>
              <div class="column right">
                <Box
                  borderWidth={1}
                  width="full"
                  maxWidth="450px"
                  p={4}
                  borderRadius={4}
                  textAlign="center"
                  boxShadow="lg"
                  align='center'
                  my="10%"
                  
                >
                  <Box >
                  <Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={4}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                      borderColor="brand.700"
                    >
                        Créer votre compte 
   
                    </Box>
                    <RegistrationForm />
                  </Box>
                </Box>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </>
    );
  }
}

class RegistrationForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPassword: false,
      passwordvalide:false,
    };
    this.nomEl = React.createRef();
    this.prenomEl = React.createRef();
    this.motPasseEl = React.createRef();
    this.confirmMotPasseEl = React.createRef();
    this.telephoneEl = React.createRef();
    this.emailEl = React.createRef();
  }
  static contextType = GlobalContext;

  photoSelectedHandle = (event) => {
    this.setState({ photo: event.target.files[0] });
  };
  handleClickPassword = () => this.setState({ showPassword: !this.state.showPassword });
  submitHandler = (event) => {
    event.preventDefault();
    const nom = this.nomEl.current.value;
    const prenom = this.prenomEl.current.value;
    const motPasse = this.motPasseEl.current.value;
    const telephone = this.telephoneEl.current.value;
    const email = this.emailEl.current.value;
    this.context.registration(nom, prenom, motPasse, email, telephone)


  };
  handlePasswordChange=()=>{
    const motPasse = this.motPasseEl.current.value;
    const confirmMotPasse = this.confirmMotPasseEl.current.value;
    if (motPasse===confirmMotPasse) {
      this.setState({ passwordvalide: !this.state.passwordvalide });
    }
  }
  render() {
    if (this.context.loginRedirect) {
      return <Redirect to="/login" />
    }
    return (
      <Box my={1} textAlign="left">
        <form onSubmit={this.submitHandler}>

            <FormControl id="nom" isRequired>
              <FormLabel>Nom</FormLabel>
              <Input type="text"
                placeholder="Entrer votre nom"
                arial-table="nom"
                ref={this.nomEl} />
            </FormControl>
            <FormControl id="prenom">
              <FormLabel>Prenom</FormLabel>
              <Input type="text"
                placeholder="Entrer votre prenom"
                arial-table="prenom"
                ref={this.prenomEl} />
            </FormControl>

          <FormControl id="telephone" isRequired>
            <FormLabel>Téléphone</FormLabel>
            <Input type="text"
              placeholder="Entrer votre Téléphone"
              arial-table="telephone"
              ref={this.telephoneEl} />
          </FormControl>
          <FormControl id="mail" isRequired>
            <FormLabel>Email</FormLabel>
            <Input type="email"
              placeholder="Entrer votre mail"
              arial-table="mail"
              ref={this.emailEl} />
          </FormControl>
  
          <FormControl id="password" mt={4} isRequired>
            <FormLabel>Mot de passe</FormLabel>
            <InputGroup>
              <Input
                onChange={this.handlePasswordChange}
                type={this.state.showPassword ? "text" : "password"}
                placeholder="mot de passe"
                arial-table="password"
                ref={this.motPasseEl}
              />
            </InputGroup>
          </FormControl>
          <FormControl id="confirmation" mt={4} isRequired>
            <FormLabel>Confirmation</FormLabel>
            <InputGroup>
              <Input
              onChange={this.handlePasswordChange}
                type={this.state.showPassword ? "text" : "password"}
                placeholder="confirmer"
                arial-table="password"
                ref={this.confirmMotPasseEl}
              />
              <InputRightAddon children={this.state.passwordvalide ? <i class="fas fa-check"></i>: <i class="fas fa-times"></i>}/>
            </InputGroup>
          </FormControl>
          <Button
            m={2}
            border="2px"
            width="full"
            background="brand.700"
            color="white"
            type='submit'
          >
            VALIDER
            </Button>

        </form>

      </Box>
    );
  }
}
