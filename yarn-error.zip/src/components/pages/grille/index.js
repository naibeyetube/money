import React, { useState } from "react";
import GrilleForm from './form'
import { Box } from "@chakra-ui/react";
import ListeGrille from "./list";
const Grille = (props) => {
  const [grille, setGrille] = useState({ })
  const [pin, setPin]=useState(props.pin)
  const getGrille = (item) => {
    setGrille({ ...item })

  }
  const getPin = (item) => {
    setPin(item)

  }

  return (
    <>
      <div className="column left">
      <Box my={1}
         width="full"
         textAlign="left" 
         boxShadow="lg"
         p={4}
        >
        <GrilleForm profile={props.profile} grille={grille}  getPin={getPin} getGrille={getGrille}/>
        </Box>
      </div>
      <div class="column right">
      <Box my={1}
         width="full"
         textAlign="left" 
         boxShadow="lg"
         p={4}
         
        >
        <ListeGrille profile={props.profile} pin={pin} getGrille={getGrille} grille={grille}/>
        </Box>
      </div>
    </>
  )
}
export default Grille
