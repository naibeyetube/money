import React, { Component, useState, useEffect, useContext } from "react";
import {
    Box,
    FormControl,
    Input,
    Button,
    FormLabel,
    Heading,
    Divider,
    useToast,
    Modal,
    ModalBody,
    ModalCloseButton,
    ModalContent,
    ModalOverlay,
    ModalHeader,
    useDisclosure,
    HStack,
    PinInput,
    PinInputField,
    NumberInput,
    NumberInputField,
    Tabs, TabList, TabPanels, Tab, TabPanel,
} from "@chakra-ui/react";
import axios from "axios";
import { GlobalContext } from "../../../context/auth-context";
import BigInt from "big-integer";
import CryptoJS from "crypto-js"
import "../../../App.css"

const GrilleForm = (props) => {
    const profile_idEl = React.createRef();
    const minmontantEl = React.createRef();
    const maxmontantEl = React.createRef();
    const fraistransfertEl = React.createRef();
    const fraisdepotEl = React.createRef();
    const fraisretraitEl = React.createRef();
    const [grille, setGrille] = useState({ id: "", profile_id: props.profile.id, minmontant: 0, maxmontant: 0, fraistransfert: 0, fraisdepot: 0, fraisretrait: 0 })
    const [pin, setPin] = useState("")
    const [deleteItem, setDeleteItem] = useState(false)
    const context = useContext(GlobalContext);
    const { isOpen, onOpen, onClose } = useDisclosure();
    const toast = useToast()
    const openPin = (event) => {
        event.preventDefault();
        onOpen()
    }
    const submitHandler = async (event) => {
        event.preventDefault();
        const P = BigInt(CryptoJS.SHA256(pin), 16)
        const dataSK = await context.decrypt(context.KDF(P, context.IV, 32), context.IV, context.dataSK)

        const dataSend = context.encrypt(dataSK.SK, context.IV, grille)
        if (grille.id) {
            try {

                axios.put("/grille" ,{ data: dataSend }).then((res) => {
                    const dataResponse = context.decrypt(dataSK.SK, context.IV, res.data.response)
                    props.getPin(pin)
                    setPin("")
                    props.getGrille(dataResponse)
                    setGrille({ ...grille, id: "", profile_id: props.profile.id, minmontant: 0, maxmontant: 0, fraistransfert: 0, fraisdepot: 0, fraisretrait: 0 })

                    toast({
                        title: "Mise à jour.",
                        description: res.data.message,
                        status: "success",
                        duration: 9000,
                        isClosable: true,
                        position: "top",
                    })

                });
            } catch (e) {
                console.log(e)
            }
        }
        else {

            await axios.post("/grille" ,{ data: dataSend }).then((res) => {
                if (res.status !== 200 && res.status !== 201) {
                    throw new Error("Failed");
                }
                return res.data
            }).then((data) => {
                const dataResponse = context.decrypt(dataSK.SK, context.IV, data.response)
                props.getPin(pin)
                setPin("")
                props.getGrille(dataResponse)
                setGrille({ id: "", profile_id: props.profile.id, minmontant: 0, maxmontant: 0, fraistransfert: 0, fraisdepot: 0, fraisretrait: 0 })
                toast({
                    title: "Ajout",
                    description: data.message,
                    status: "success",
                    duration: 9000,
                    isClosable: true,
                    position: "top",
                })

            });
        }
        
    };

    const deleteHandle = async () => {
        await axios.delete(`/grille/${grille.id}`).then((res) => {

            // props.getgrille(res.data.Grille)
            toast({
                title: "Suppression.",
                description: res.data.message,
                status: "success",
                duration: 9000,
                isClosable: true,
                position: "top",
            })

        });
        setPin("")
        setGrille({ id: "", profile_id: props.profile.id, minmontant: 0, maxmontant: 0, fraistransfert: 0, fraisdepot: 0, fraisretrait: 0 })

    }
    useEffect(() => {
        setGrille({ ...grille,...props.grille })
    }, [ props.profile]);
    return (
        <>
            <Box my={1} textAlign="center">
                <Heading as="h2" size="md" color="brand.700" textAlign="center">
                    Tarifs des transactions
            </Heading>
                <Divider orientation="horizontal" m={2} />
                <form onSubmit={openPin}>
                    <Tabs
                        variant="enclosed" borderRadius={4}
                        fontSize={{ base: "10px", md: "16px", lg: "16px" }}
                        align='center'
                    >
                        <TabList>
                            <Tab _selected={{ color: "white", bg: "brand.700" }}
                                mt={4}
                                border="2px"
                                borderColor="brand.700"
                                variant="solid"
                                fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                            >Grille</Tab>
                            <Tab _selected={{ color: "white", bg: "brand.700" }}
                                mt={4}
                                border="2px"
                                borderColor="brand.700"
                                variant="solid"
                                fontSize={{ base: "12px", md: "16px", lg: "16px" }}
                            >Frais</Tab>
                        </TabList>
                        <TabPanels>
                            <TabPanel>
                                <FormControl id="semestre" isRequired isDisabled={true} >
                                    <FormLabel>Profile</FormLabel>
                                    <Input type="text"
                                        value={props.profile.intitule}
                                        arial-table="telephone"/>
                                </FormControl>
                                <FormControl id="seuiljour" isRequired>
                                    <FormLabel>Min montant</FormLabel>
                                    <NumberInput
                                        onChange={(value) => { setGrille({ ...grille, minmontant: value }) }}
                                        arial-table="code"
                                        ref={minmontantEl}
                                        value={grille.minmontant}
                                        min={500}

                                    >
                                        <NumberInputField />
                                    </NumberInput>
                                </FormControl>
                                <FormControl id="seuiljour" isRequired>
                                    <FormLabel>Max montant</FormLabel>
                                    <NumberInput
                                        onChange={(value) => { setGrille({ ...grille, maxmontant: value }) }}
                                        arial-table="code"
                                        ref={maxmontantEl}
                                        value={grille.maxmontant}
                                        min={500}

                                    >
                                        <NumberInputField />
                                    </NumberInput>
                                </FormControl>

                            </TabPanel>
                            <TabPanel>
                                <FormControl id="seuiljour" isRequired>
                                    <FormLabel>Frais transfert</FormLabel>
                                    <NumberInput
                                        onChange={(value) => { setGrille({ ...grille, fraistransfert: value }) }}
                                        arial-table="code"
                                        ref={fraistransfertEl}
                                        value={grille.fraistransfert}

                                    >
                                        <NumberInputField />
                                    </NumberInput>
                                </FormControl>
                                <FormControl id="seuilsemaine" isRequired>
                                    <FormLabel>Frais depôt</FormLabel>
                                    <NumberInput
                                        onChange={(value) => { setGrille({ ...grille, fraisdepot: value }) }}
                                        arial-table="code"
                                        ref={fraisdepotEl}
                                        value={grille.fraisdepot}
                                    >
                                        <NumberInputField />
                                    </NumberInput>
                                </FormControl>
                                <FormControl id="seuiljour" isRequired>
                                    <FormLabel>Frais retrait</FormLabel>
                                    <NumberInput
                                        onChange={(value) => { setGrille({ ...grille, fraisretrait: value }) }}
                                        arial-table="code"
                                        ref={fraisretraitEl}
                                        value={grille.fraisretrait}
                                    >
                                        <NumberInputField />
                                    </NumberInput>
                                </FormControl>
                            </TabPanel>
                        </TabPanels>
                    </Tabs>


                    <Button
                        m={2}
                        border="2px"
                        background="brand.700"
                        color="white"
                        type='submit'

                    >
                        {grille.id ? "Mettre à jour" : "Valider"}
                    </Button>
                    <Button
                        m={2}
                        border="2px"
                        background="brand.700"
                        color="white"
                        isDisabled={grille.id && !deleteItem ? false : true}
                        onClick={(event) => { openPin(event); if (pin) deleteHandle() }}

                    >
                        Supprimer
            </Button>
                </form>

            </Box>
            <Modal
                isOpen={isOpen}
                onClose={onClose}
                id="pin"
                size="xs"
            >
                <ModalOverlay />
                <ModalContent>
                <ModalHeader><Box
                      borderWidth={1}
                      width="full"
                      p={2}
                      borderRadius={2}
                      textAlign="center"
                      boxShadow="lg"
                      align='center'
                      color="brand.700"
                      m={2}
                    >
                        SESSION PIN
   
                    </Box></ModalHeader>
                    <ModalCloseButton />
                    <ModalBody pb={6}>

                        <form onSubmit={submitHandler}>
                            <Box
                                borderWidth={1}
                                width="full"
                                p={4}
                                borderRadius={4}
                                boxShadow="lg"
                                textAlign="center"
                                alignContent="center"
                            >
                                <FormControl mt={4} isRequired>
                                    <HStack align="center">
                                        <PinInput
                                            onChange={(value) => { setPin(value) }}
                                            mask>
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                            <PinInputField />
                                        </PinInput>
                                    </HStack>

                                </FormControl>
                            </Box>
                            <HStack mt={4}>
                                <Button
                                    border="2px"
                                    borderColor="brand.700"
                                    variant="solid"
                                    background="brand.700"
                                    color="white"
                                    variant="outline"
                                    mr={3}
                                    type="submit"
                                    onClick={onClose }>
                                    Valider
                                </Button>

                            </HStack>
                        </form>

                    </ModalBody>
                </ModalContent>
            </Modal>
        </>
    );
}
export default GrilleForm