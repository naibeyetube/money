import React from "react";
import { NavLink } from "react-router-dom";
import AuthContext from "../../context/auth-context";
import {
  Flex,
  Box,
  useColorMode,
  Heading,
  Divider
} from "@chakra-ui/core";
import "../../App.css"
const VARIANT_COLOR = "blue";
const Footer = (props) => {
  const { colorMode, toggleColorMode } = useColorMode();
  const color = colorMode === "light" ? "brand.700" : "white"
  return (
    <>
     <footer>
        <span> Developped by Naibeye Sidoine| <span className="far fa-copyright"></span> 2021 All rights reserved.</span>
    </footer>
    </>
  );
}


export default Footer;
