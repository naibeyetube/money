import React, { useState, useEffect, useContext } from "react";
import { Redirect, NavLink, useHistory } from "react-router-dom";
import { GlobalContext } from "../../context/auth-context";
import {
  Flex,
  Box,
  useColorMode,
  Heading,
  Divider,
  Link,
  IconButton,
  background
} from "@chakra-ui/react";
import { Fragment } from "react";
const VARIANT_COLOR = "blue";
const Header = (props) => {
  const context = useContext(GlobalContext)

  const { colorMode, toggleColorMode } = useColorMode();
  const color = colorMode === "light" ? "brand.700"  :"white"
  const [lien, setLien] = useState("/")
  let history = useHistory();

  return (

    <Fragment>
      <div className="scroll-up-btn">
        <i className="fas fa-angle-up"></i>
      </div>

      <nav className="navbar">
        <div className="max-width">
          <div className="logo"><a href="#">Naibeye<span>DIGIT</span></a></div>
          <ul className="menu">
            {<li><a href="/" >Accueil</a></li>}
            {context.dataSK && <li><a href="/cash">NaibeyeMoney</a></li>}
            {context.dataSK && <li><a onClick={(e) => { e.preventDefault(); context.logout(); history.push('/login') }}>Quitter</a></li>}

            {!context.dataSK && <li><a href="/create">Créer un compte</a></li>}
            {!context.dataSK && <li><a href="/login">Connexion</a></li>}
            

            <li>
              <IconButton
                icon={colorMode === "light" ?<i className="fas fa-sun"></i>  : <i className="fas fa-moon"></i>}
                onClick={toggleColorMode}
              />
            </li>
          </ul>
          <div className="menu-btn">
            <i class="fas fa-bars"> </i>
          </div>
        </div>
      </nav>
    </Fragment>
  );
}


export default Header;
