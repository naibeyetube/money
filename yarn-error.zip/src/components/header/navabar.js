import React from "react";
import { NavLink} from "react-router-dom";
import {
  Flex,
  Stack,
  IconButton,
  Box,
  useColorMode,
  Button,

} from "@chakra-ui/core";

const VARIANT_COLOR = "blue";
const navabar = (props) => {
      return (
        <Flex > 
          <Box bg={`${VARIANT_COLOR}.700`} width={'100%'} p={2} fontSize={["sm", "md", "lg", "xl"]} color="white">
            <Flex justify="center">
              { <Stack isInline  >
                <Box>
                <NavLink to="/">
                  <Button>       
                      Accueil
                  </Button>
                  </NavLink>
                </Box>
                <Box >
                <NavLink to="/formations">
                  <Button bg={`${VARIANT_COLOR}.700`}>
                      Formations
                  </Button>
                  </NavLink>
                </Box>
                <Box>
                <NavLink to="/departements">
                  <Button bg={`${VARIANT_COLOR}.700`}  >
                    
                      Départements
                    
                  </Button>
                  </NavLink>
                </Box>
                <Box fontSize={["sm", "md", "lg", "xl"]}>
                <NavLink to="/recherches">
                  <Button bg={`${VARIANT_COLOR}.700`}>
                    
                      Recherches et coopérations
                    
                  </Button>
                  </NavLink>
                </Box>
                <Box fontSize={["sm", "md", "lg", "xl"]}>
                <NavLink to="/contacts">
                  <Button bg={`${VARIANT_COLOR}.700`} >
                    
                      Contact
                   
                  </Button>
                  </NavLink>
                </Box >
                <Box>
                <NavLink to="/eservices">
                  <Button bg={`${VARIANT_COLOR}.700`}>
                    
                      E-services
                    
                  </Button>
                  </NavLink>
                </Box>
                <Box>
                  <ThemeSelector />
                </Box>
              </Stack>}
            </Flex>
          </Box>
        </Flex>
      );
              }
const ThemeSelector = () => {
  const { colorMode, toggleColorMode } = useColorMode();

  return (
    <Box textAlign="right">
      <IconButton
        icon={colorMode === "light" ? "moon" : "sun"}
        onClick={toggleColorMode}
        variant="ghost"
      />
    </Box>
  );
};

export default navabar;
