export default (state, action) => {
  switch (action.type) {
    case "CREATE":
      return  {
        ...state,
        loginRedirect: action.payload.loginRedirect,
      };
      case "LOGIN":
      return {
        ...state,
        dataSK: action.payload.dataSK,
      };
      case "RETRIEVE_TOKEN":
      return {
        ...state,
        dataSK: action.payload.dataSK,
        dataUser: action.payload.dataUser,
      };
      case "LOGOUT":
      return {
        ...state,
        dataSK: null,
        dataUser: {},
        loginRedirect: false
      };
    default:
      return state;
  }
};
