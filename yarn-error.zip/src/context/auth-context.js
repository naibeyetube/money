import React, { createContext, useReducer } from "react";
import axios from "axios";
import CryptoJS from 'crypto-js';
import BigInt from 'big-integer';
import AppReducer from "./appReducer";
const initialState = {
  dataSK: null,
  dataUser: null,
  user:{},
  N:BigInt("23206643651258734647606095594200799763769381986605416589345550441667501525855150199952652456457030559317664904678690996664063688922864102130064467744106016372087650772207250185201994817238759019621854582352607340176358282867327719893117473727741751627275722824966846269994627045504287207864170514563679722332933738239782611395050223785424712391127758874994756898555648837402476003628944356905517898806933058846070050030692577118332820994688974821492928832339942976418393385628872292987990687623864807846653073583506851384956071188244650698891693830393307890557449362342938118371097004464486962226150100237990946777591"),
  G1:BigInt("687737697466929425125528840757"),
  G2:BigInt("21962863346329838765298769526890241703806653625747457150314134921228994579935501129567721077964930214724402845365045453891635632659023612355378607981644521409812345671422741388759596096177530566019138903494322184199574625552477788189620763295332789768132112069038540884613895789594981631776664614043456659729290407567468350705570188833113660001214729709025839120571042299230199541269817985272665101002759140996204053148074161105566516480053566856945071788514266827509674369341519576905815778824739837129101516377426009134687195831883818929787311774941655003947465010881577515107066193236235808134236330935019598528053"),
  P2:BigInt("11713917760751290338900650827214603518348794816664631706874728683533658754048327060406822433733614749493474096819522837749703773039061674471447242345317482909055785908346991277991322366797123974136003640523512931365594783424543784928319489836514641680060082648189720257958816016054458410013768378491692849312249218027819587779019529443141973492826782992387270658150333266607127319663979581629801362062111215813068122631340243040197510564613712809681628086186725856227956394156947220077272965636394804877361013858029630681510044653694950629891530371029998706534755662573060274317935570912699825904065289974265593086602"),
  P1:BigInt("3300777240255232536840016235727903335427290905372219973239106311790345948295056082271902971703670930708321028466277963961118726958405662458838819306575515957744792334769052225624637468946678738777237219873839818463338838716384815916784197821748405599076612731401105070736320443437499654703090418730987834468059563458558330243727395864601588321216505263063001152155790982532929143198716018466772317528994048163060928150888032505893424622519699092559726012711687136898094192776505950506487939905635042441924273235465899968798640808879750088269229869978741035366660117391699256848877773453883602972593054308959150353844"),

  IV:"pajCPhwua8yfYRE6",
  loginRedirect:false
};
const encrypt = (key, iv, msg) => {
  const key_byte = CryptoJS.enc.Utf8.parse(key)
  const iv_byte = CryptoJS.enc.Utf8.parse(iv)
  const encrypted_text = CryptoJS.AES.encrypt(JSON.stringify(msg), key_byte, { iv: iv_byte, mode: CryptoJS.mode.CFB, padding: CryptoJS.pad.ZeroPadding })
  const encrypted_text_hex = CryptoJS.enc.Hex.stringify(encrypted_text.ciphertext)
  return encrypted_text_hex
}
const decrypt = (key, iv, encrypted_text) => {
  const key_byte = CryptoJS.enc.Utf8.parse(key)
  const iv_byte= CryptoJS.enc.Utf8.parse(iv)
  const  encrypted_text_bin = CryptoJS.enc.Hex.parse(encrypted_text)
  const plain_text_bin = CryptoJS.AES.decrypt(CryptoJS.enc.Base64.stringify(encrypted_text_bin), key_byte, { iv: iv_byte, mode: CryptoJS.mode.CFB, padding: CryptoJS.pad.ZeroPadding })
  const  plain_text = plain_text_bin.toString(CryptoJS.enc.Utf8)
  return JSON.parse(plain_text)
}
const KDF = (key, iv, lkey) => {
  const key_byte = CryptoJS.enc.Utf8.parse(key)
  const iv_byte = CryptoJS.enc.Utf8.parse(iv)
  const hashed = CryptoJS.HmacMD5(key_byte, iv_byte)
  const hashedUtf8 = CryptoJS.enc.Base64.stringify(hashed)
  return hashedUtf8.substr(0, lkey)
}
export const GlobalContext = createContext(initialState);
export const GlobalProvider = ({ children }) => {
  
  const [state, dispatch] = useReducer(AppReducer, initialState);

  async function login(telephone, motPasse, pin) {

    try {
      const P=BigInt(CryptoJS.SHA256(pin),16)
      const a=BigInt(CryptoJS.SHA256(motPasse),16)
      const x = BigInt.randBetween("1e50", "1e250")
      const A1 =initialState.G1.modPow(a, initialState.N)
      const X = initialState.G2.modPow(x, initialState.N)
      const R = A1.times(X)
      const L = a.plus(BigInt(CryptoJS.enc.Hex.stringify(CryptoJS.SHA256(CryptoJS.enc.Utf8.parse(telephone + A1.toString()))), 16).multiply(x)).mod(initialState.N)
      const Rb = (initialState.P1.modPow(a, initialState.N).times(initialState.P2.modPow(x, initialState.N))).mod(initialState.N)
      const KRb = KDF(Rb, initialState.IV, 32)
      const Y = encrypt(KRb, initialState.IV, { "A1": A1, "L": L, "telephone": telephone })
      const headers = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
      await axios.post("/login", { Y, R})
        .then((res) => {

          if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }
          return res.data;
        })
        .then((data) => {
          const S = (Rb.times(initialState.P2.modPow(a, initialState.N))).mod(initialState.N)
          const SK= KDF(S, initialState.IV, 32)
          const PK=KDF(P, initialState.IV, 32)
          const reponse = decrypt(SK, initialState.IV, data.response)
          const dataSK=encrypt(PK, initialState.IV,{SK:SK} )
          const dataUser=encrypt(PK, initialState.IV,reponse )
          dispatch({
            type: "LOGIN",
            payload: {
              dataSK:dataSK,
              dataUser: dataUser,
            },
          });
          sessionStorage.setItem(
            "dataSK",
            dataSK

          );
          sessionStorage.setItem(
            "dataUser",
            dataUser

          );
        })
        .catch((err, res) => {
          console.log(err);
        });
    } catch (e) {
      console.log(e);
    }
  }
  async function retrieve() {
    try {
      const dataSK = await sessionStorage.getItem('dataSK');
      const dataUser = await sessionStorage.getItem('dataUser');
      dispatch({
        type: "RETRIEVE_TOKEN",
        payload: { dataSK: dataSK, dataUser: dataUser },
      });

    } catch (e) {
      console.log(e);
    }
    // console.log('user token: ', userToken);

  }
  async function registration(nom, prenom, password,email, telephone) {
    const a = BigInt(CryptoJS.SHA256(password), 16)
    const x = BigInt.randBetween("1e50", "1e250")
    const A1 = initialState.G1.modPow(a, initialState.N);
    const A2 = initialState.G2.modPow(a, initialState.N)
    const X = initialState.G2.modPow(x, initialState.N)
    const R = A1.times(X)
    const Rb = (initialState.P1.modPow(a, initialState.N).times(initialState.P2.modPow(x, initialState.N))).mod(initialState.N)
    const KRb = KDF(Rb, initialState.IV, 32)
    const Y = encrypt(KRb, initialState.IV, { "A1": A1, "A2": A2, "telephone": telephone, "nom": nom, "prenom": prenom, "email": email })
    try {
      await axios.post("/createuser", { Y, R})
        .then((res) => {
          if (res.status !== 200 && res.status !== 201) {
            throw new Error("Failed");
          }
          return res.data;
        })
        .then((data) => {
          const S = (Rb.times(initialState.P2.modPow(a, initialState.N))).mod(initialState.N)
          const SK= KDF(S,initialState.IV, 32)

          const reponse = decrypt(SK, initialState.IV, data.response)
          dispatch({
            type: "CREATE",
            payload: { loginRedirect:true },
          });
          
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (err) {
      dispatch({
        type: "TRANSACTION_ERROR",
        payload: err.response.data.error,
      });
    }
  }
  
  function logout() {
    sessionStorage.clear()
    dispatch({
      type: "LOGOUT",
    });
  }
  return (
    <GlobalContext.Provider
      value={{
        ...state,
        encrypt,
        decrypt,
        KDF,
        login,
        registration,
        retrieve,
        logout,
      }}
    >
      {children}
    </GlobalContext.Provider>
  );
};
